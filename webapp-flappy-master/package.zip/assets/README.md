# Assets - the things that make your game look good

This directory is for you to store the various graphical and sound elements you use in your game, together with the `CSS` stylesheet where you define what your game looks like!