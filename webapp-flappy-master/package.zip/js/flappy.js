// the Game object used by the phaser.io library
var stateActions = { preload: preload, create: create, update: update };

// Phaser parameters:
// - game width
// - game height
// - renderer (go for Phaser.AUTO)
// - element where the game will be drawn ('game')
// - actions on the game state (or null for nothing)
var game = new Phaser.Game(790, 400, Phaser.AUTO, 'game', stateActions);
var score = 0;
var labelScore;
var player;
var pipes = [];
//you can assign the initial color of the background here
var r=255;
var g=100;
var b=255;
var flag=0;
var t=new Array;
var o=new Array;
var d=new Array;
/*
 * Loads all resources for the game and gives them names.
 */
function preload() {

    game.load.image("playerImg", "../assets/flappy_frog.png");
    game.load.audio("score", "../assets/point.ogg");
    game.load.image("pipeBlock", "../assets/pipe_green.png")

}

/*
 * Initialises the game. This function is only called once.
 */
function create() {

    game.physics.startSystem(Phaser.Physics.ARCADE);
    // set the background colour of the scene
    game.stage.setBackgroundColor("#13a199");
    // disco();
    // setTimeout('disco()',5);

    // game.add.text(20, 20, "!", {font: "60px Arial", fill: "#abcdef"});
    // game.add.text(750, 20, "?", {font: "60px Arial", fill: "#abcdef"});
    // game.add.text(20, 340, "$", {font: "60px Arial", fill: "#abcdef"});
    // game.add.text(730, 340, "%", {font: "60px Arial", fill: "#abcdef"});
    player = game.add.sprite(50, 50, "playerImg");
    game.physics.enable(player);

    player.body.gravity.y = 200;


    // game.input.onDown.add(clickHandler);
    game.input
      .keyboard.addKey(Phaser.Keyboard.SPACEBAR)
      .onDown.add(playerJump);

      // game.input
      //   .keyboard.addKey(Phaser.Keyboard.RIGHT)
      //   .onDown.add(moveRight);
      //
      // game.input
      //   .keyboard.addKey(Phaser.Keyboard.LEFT)
      //   .onDown.add(moveLeft);
      //
      // game.input
      //   .keyboard.addKey(Phaser.Keyboard.UP)
      //   .onDown.add(moveUp);
      //
      // game.input
      //   .keyboard.addKey(Phaser.Keyboard.DOWN)
      //   .onDown.add(moveDown);
      var pipeInterval = 2 * Phaser.Timer.SECOND;
      game.time.events.loop(
        pipeInterval,
        generatePipe,
        disco
      );

    score = score + 1;
    labelScore = game.add.text(20, 20, "0");

}

/*
 * This function updates the scene. It is called for every new frame.
 */

function update() {
 game.physics.arcade.overlap(
 player,
 pipes,
 gameOver);
}
function gameOver(){
 game.destroy();
}

function addPipeBlock(x, y){
  var block = game.add.sprite(x, y, "pipeBlock");
  pipes.push(block);

  game.physics.arcade.enable(block);
  block.body.velocity.x = -150;
}
function generatePipe(){
  var gapStart = game.rnd.integerInRange(1, 5);
  for(var count = 0; count<8; count = count + 1){
    if(count != gapStart && count != gapStart + 1) {
        addPipeBlock(800, count * 50);
    }
  }
  changeScore()
}

function playerJump(){
  player.body.velocity.y = -100;
}
function clickHandler(event) {
  // alert("Hello!");
    // game.add.sprite(event.x, event.y, "playerImg");
    game.sound.play("score");
    score = score + 1;
    labelScore.setText(score.toString());
}

function moveRight(){
  player.x = player.x + 10;
}

function moveLeft(){
  player.x = player.x - 10;
}

function moveUp(){
  player.y = player.y - 10;
}

function moveDown(){
  player.y = player.y + 10;
}
function spaceHandler() {
  changeScore();
 game.sound.play("score");
}

function changeScore() {
 score = score + 1;
 labelScore.setText(score.toString());
}

function hex(a,c){
  t[a]=Math.floor(c/16)
  o[a]=c%16
  switch (t[a]){
    case 10:
    t[a]='A';
    break;
    case 11:
    t[a]='B';
    break;
    case 12:
    t[a]='C';
    break;
    case 13:
    t[a]='D';
    break;
    case 14:
    t[a]='E';
    break;
    case 15:
    t[a]='F';
    break;
    default:
    break;
  }
  switch (o[a])    {
    case 10:
    o[a]='A';
    break;
    case 11:
    o[a]='B';
    break;
    case 12:
    o[a]='C';
    break;
    case 13:
    o[a]='D';
    break;
    case 14:
    o[a]='E';
    break;
    case 15:
    o[a]='F';
    break;
    default:
    break;
  }
}

function ran(a,c) {
  if ((Math.random()>2/3||c==0)&&c<255){
    c++
    d[a]=2;
  } else {
    if ((Math.random()<=1/2||c==255)&&c>0){
      c--
      d[a]=1;
    } else d[a]=0;
  }
  return c
}

function do_it(a,c){
  if ((d[a]==2&&c<255)||c==0){
    c++
    d[a]=2
  }else if ((d[a]==1&&c>0)||c==255){
    c--;
    d[a]=1;
  }if (a==3){
    if (d[1]==0&&d[2]==0&&d[3]==0)
    flag=1
  }
  return c
}

function disco(){
  if (flag==0){
    r=ran(1, r);
    g=ran(2, g);
    b=ran(3, b);
    hex(1,r)
    hex(2,g)
    hex(3,b)
    game.stage.setBackgroundColor("#"+t[1]+o[1]+t[2]+o[2]+t[3]+o[3]);
    console.log("#"+ t[1]+o[1]+t[2]+o[2]+t[3]+o[3]);

    flag=50
  }else{
    r=do_it(1, r)
    g=do_it(2,g)
    b=do_it(3,b)
    hex(1,r)
    hex(2,g)
    hex(3,b)
    game.stage.setBackgroundColor("#"+t[1]+o[1]+t[2]+o[2]+t[3]+o[3]);
    console.log("#"+t[1]+o[1]+t[2]+o[2]+t[3]+o[3]);
    flag--
  }
}
