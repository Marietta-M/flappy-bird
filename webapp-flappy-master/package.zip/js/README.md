# Your own game

Very likely only your Game JavaScript code will live here -- this is the code you have previously written for the game