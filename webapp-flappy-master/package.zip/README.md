# Web App for your game

Everything online needs a web page!

This is the starting point for you to create your own web app for your flappy bird game, on the second day of the [Cambridge Coding Academy Summer School](http://cambridgecoding.com/summer-school) 
